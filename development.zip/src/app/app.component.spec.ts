import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { expect, use } from 'chai';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { SavedSearchesComponent } from './components/saved-searches/saved-searches.component';
import { NoSavedSearchesComponent } from './components/no-saved-searches/no-saved-searches.component';
describe('AppComponent', () => {
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [
				AppComponent,
				SavedSearchesComponent,
				NoSavedSearchesComponent
			], imports: [HttpClientTestingModule]
		}).compileComponents();
	}));

	// it('should create the app', () => {
	// 	const fixture = TestBed.createComponent(AppComponent);
	// 	const app = fixture.debugElement.componentInstance;
	// 	expect(app).to.be.true();
	// });

	it(`should have as title 'nw-ui-wc-saved-searches'`, () => {
		const fixture = TestBed.createComponent(AppComponent);
		const app = fixture.debugElement.componentInstance;
		expect(app.title).to.be.equal('nw-ui-wc-saved-searches');
	});

	// it('should render title in a h1 tag', () => {
	//   const fixture = TestBed.createComponent(AppComponent);
	//   fixture.detectChanges();
	//   const compiled = fixture.debugElement.nativeElement;
	//   expect(compiled.querySelector('h1').textContent).toContain('Welcome to nw-ui-wc-saved-searches!');
	// });
	// });
});
