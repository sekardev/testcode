import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';


import { AppComponent } from './app.component';
import { SavedSearchesComponent } from './components/saved-searches/saved-searches.component';
import { NoSavedSearchesComponent } from './components/no-saved-searches/no-saved-searches.component';

@NgModule({
	declarations: [
		AppComponent,
		SavedSearchesComponent,
		NoSavedSearchesComponent
	],
	imports: [
		BrowserModule, ReactiveFormsModule, HttpClientModule
	],
	schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
	bootstrap: [],
	providers: [{ provide: 'windowObject', useFactory: getWindow }],
	entryComponents: [AppComponent]
})
export class AppModule {
	constructor(private injector: Injector) { }

	ngDoBootstrap() {
		const nwUiWcSavedSearches = createCustomElement(AppComponent, { injector: this.injector });
		// customElements.define('nw-ui-wc-saved-searches', nwUiWcSavedSearches);
		if (!customElements.get('nw-ui-wc-saved-searches')) customElements.define('nw-ui-wc-saved-searches', nwUiWcSavedSearches);
	}
}

export function getWindow() {
	return window;
}