import { Component, OnInit, OnChanges, Input } from '@angular/core';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})


export class AppComponent implements OnInit {


	title = 'nw-ui-wc-saved-searches';

	showSavedSearches = false;



	constructor() { }

	ngOnInit() {

	}

}



