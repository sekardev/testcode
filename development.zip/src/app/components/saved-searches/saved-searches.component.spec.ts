import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { expect, use } from 'chai';

import { SavedSearchesComponent } from './saved-searches.component';
import { MockEnvironmentService, MockSavedSearchService, } from 'src/mocks/mockClasses';
import { NoSavedSearchesComponent } from '../no-saved-searches/no-saved-searches.component';
import { EnvironmentService } from 'src/app/services/environment.service';
import { SavedSearchService } from 'src/app/services/saved-search.service';
import { savedSearchMock } from 'src/mocks/mockGetSavedSearch';
import { Observable } from 'rxjs';
import { HttpClient } from 'selenium-webdriver/http';

describe('SavedSearchComponent', () => {

	let testHostFixture: ComponentFixture<SavedSearchesComponent>;
	let testSavedSearchComponent: SavedSearchesComponent;
	const mockEnvService = new MockEnvironmentService(false);
	let mockSearchService: MockSavedSearchService;
	let testBedService: SavedSearchService;


	beforeEach(async(async () => {



		TestBed.configureTestingModule({
			declarations: [
				SavedSearchesComponent, NoSavedSearchesComponent
			],
			providers: [
				SavedSearchService, EnvironmentService
			]
		}).overrideComponent(SavedSearchesComponent, {
			set: {
				providers: [
					{ provide: SavedSearchService, useClass: MockSavedSearchService },
					{ provide: EnvironmentService, useClass: MockEnvironmentService }
				]
			}

		})
			.compileComponents();
		//TestBed.overrideProvider(SavedSearchService, { useValue: MockSavedSearchHttpClient });
		// TestBed.overrideProvider(EnvironmentService, { useValue: mockEnvService });
		testHostFixture = await TestBed.createComponent(SavedSearchesComponent);
		testSavedSearchComponent = testHostFixture.componentInstance;
		await testHostFixture.detectChanges();
	}));


	describe('ngOnInit', () => {


		beforeEach(async(async () => {

			await testSavedSearchComponent.ngOnInit();
		}));

		it('should return component variables', (async) => {

			expect(testSavedSearchComponent.savedSearchList).to.be.exist;
			expect(testSavedSearchComponent.savedSearchRecords).to.be.exist;
			expect(testSavedSearchComponent.IsSaveSearchExist).to.be.exist;

		});
	});

});


