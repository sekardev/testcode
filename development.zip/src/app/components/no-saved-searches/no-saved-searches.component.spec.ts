import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoSavedSearchesComponent } from './no-saved-searches.component';

describe('NoSavedSearchesComponent', () => {
	let component: NoSavedSearchesComponent;
	let fixture: ComponentFixture<NoSavedSearchesComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [NoSavedSearchesComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(NoSavedSearchesComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		//expect(component).toBeTruthy();
	});
});
