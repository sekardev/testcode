import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'no-saved-searches',
	templateUrl: './no-saved-searches.component.html',
	styleUrls: ['./no-saved-searches.component.scss']
})
export class NoSavedSearchesComponent implements OnInit {

	constructor() { }

	ngOnInit() {
	}

}
