export interface savedSearchResponse {
	searchText: string;
	searchName: string;
	newVehicles: number;
	totalVehicles: number;
} 