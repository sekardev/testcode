import { TestBed, getTestBed } from '@angular/core/testing';
import { SavedSearchService } from './saved-search.service';

import { expect, use } from 'chai';
import { HttpClientModule, HttpClient } from '@angular/common/http';

import { savedSearchMock } from 'src/mocks/mockGetSavedSearch';
import { savedSearchMockCount } from 'src/mocks/mockSavedSearchCount';
import { MockEnvironmentService, MockSavedSearchService } from 'src/mocks/mockClasses';

describe('SavedSearchService', () => {
	let savedSearchService: SavedSearchService;
	beforeEach(() => {
		TestBed.configureTestingModule({

			imports: [
				HttpClientModule
			],
			providers: [
				SavedSearchService,
				{
					provide: HttpClient, useClass: MockSavedSearchService
				}
			]
		});
		savedSearchService = TestBed.get(SavedSearchService);
		savedSearchService.ngOnInit();
	}

	);

	// TODO: add post to MockSavedSearchHttpClient for this method
	it('should return saved search results', async () => {
		const result = savedSearchService.getSavedSearch();
		expect(4).to.be.equal(savedSearchMock.length);

	});
	it('should return eMPTY results', async () => {
		const result = savedSearchService.getSavedSearch();
		expect(4).to.be.equal(savedSearchMock.length);

	});
	it('should validate ng onit', async () => {
		savedSearchService.ngOnInit();

		savedSearchService.plId = "2";
		savedSearchService.getSavedSearch();

	});
	it('should return vehicle count search results', async () => {


		const result = savedSearchService.getVehicleCount("Cartype").then((d) => {
			expect(result).to.be.equal(d);
		})


	});


});


