import { Injectable } from '@angular/core';
import { getEnvironment } from '../../environments/environment';

@Injectable({
	providedIn: 'root'
})
export class EnvironmentService {
	private environment: any;

	constructor() { }

	getEnvironment(): any {
		if (!this.environment) {
			this.environment = getEnvironment();
		}
		return this.environment;
	}
}
