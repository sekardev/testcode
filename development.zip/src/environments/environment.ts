// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export function getEnvironment() {
	const hostname = window.location.hostname;
	//const settings = require(`../assets/environments/${hostname}.json`);
	const settings = JSON.parse(sessionStorage.getItem(`environment-${hostname}`));

	return {
		production: false,
		buyerOa: 'https://buy.test1.adesa.com/openauction',
		amgUrl: 'https://amg.test1.adesa.com/amgsearch/api/rest/1.0',
		savedsearchUrl: "https://nw-search-apigw-testdev.nw.adesa.com/testdev/api/search/getSearch",
		savedsearchcountsUrl: "https://nw-search-apigw-testdev.nw.adesa.com/testdev/api/search/savedSearchCounts/"
	};
}



/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
