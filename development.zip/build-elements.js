const fs = require('fs-extra');
const concat = require('concat');
const createHTML = require('create-html');

const body = `

<nw-ui-wc-saved-searches></nw-ui-wc-saved-searches>

<script src="nw-ui-wc-saved-searches/nw-ui-wc-saved-searches.js"></script>
`;

const head = `
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
`;

(async function build() {
	const files = [
		'./lib/scripts.js',
		'./lib/main.js',
		'./lib/polyfills.js',
		'./lib/styles.js',
		'./lib/vendor.js',
		'./lib/runtime.js',
		'./lib/es2015-polyfills.js',
		'./lib/nw-ui-wc-saved-searches.js'
	];

	const html = createHTML({
		head,
		body
	})

	await concat(files, 'lib/nw-ui-wc-saved-searches.js');

	// files.forEach(file => {
	// 	fs.unlink(file, function (err) {
	// 		if (err) return console.log(err);
	// 		console.log('file deleted successfully');
	// 	})
	// });

	// if (!fs.existsSync('lib/index.html')) {
	// 	fs.writeFile('lib/index.html', html, function (err) {
	// 		if (err) console.log(err)
	// 	})
	// }
})();
